This application is a fictional E-Store front that uses a GUI that I created using .swing classes in java. When the user checks out, they will receive a pop-up invoice. The program also outputs the items that the user checked out with into a "transactions.csv" file. If this file is not already created the program will create it automatically.

****NOTE****
Items need to be looked up by their code which can be found in "inventory.csv" -- Item Codes are REQUIRED to search for items
This .csv file also includes the item quantity in stock, as well as a Boolean telling the system if the item is available. 

The code is compressed into a runnable .jar file.
in order for the system to work, the "inventory.csv" file needs to be in the same directory as the executable .jar



Thanks for viewing my project!

-James Eyler